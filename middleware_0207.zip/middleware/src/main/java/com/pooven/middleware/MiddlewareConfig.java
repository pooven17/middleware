package com.pooven.middleware;

import java.util.function.Consumer;

import javax.validation.Validation;
import javax.validation.Validator;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.Message;
import org.springframework.security.config.web.server.ServerHttpSecurity;
import org.springframework.security.oauth2.client.registration.ReactiveClientRegistrationRepository;
import org.springframework.security.oauth2.client.web.reactive.function.client.ServerOAuth2AuthorizedClientExchangeFilterFunction;
import org.springframework.security.oauth2.client.web.server.ServerOAuth2AuthorizedClientRepository;
import org.springframework.security.web.server.SecurityWebFilterChain;
import org.springframework.web.reactive.function.client.WebClient;

import com.pooven.middleware.model.EventData;
import com.pooven.middleware.service.MiddlewareService;

import reactor.core.publisher.Flux;

@Configuration
public class MiddlewareConfig {

	@Bean
	public Consumer<Flux<Message<EventData>>> sink(MiddlewareService service) {
		return msg -> msg.map(message -> service.trigger(message)).doOnNext(s -> ack(msg))
				.doOnError(e -> reject(msg, e)).subscribe();
	}

	private void ack(Flux<Message<EventData>> msg) {
		// Impl to acknowledge
	}

	private void reject(Flux<Message<EventData>> msg, Throwable e) {
		// Impl to reject due to error
	}

	@Bean
	WebClient webClient(ReactiveClientRegistrationRepository clientRegistrations,
			ServerOAuth2AuthorizedClientRepository authorizedClients) {
		ServerOAuth2AuthorizedClientExchangeFilterFunction oauth = new ServerOAuth2AuthorizedClientExchangeFilterFunction(
				clientRegistrations, authorizedClients);
		oauth.setDefaultClientRegistrationId("middleware");
		return WebClient.builder().filter(oauth).build();
	}

	@Bean
	public SecurityWebFilterChain securitygWebFilterChain(ServerHttpSecurity http) {
		return http.authorizeExchange().anyExchange().permitAll().and().build();
	}

	@Bean
	public Validator getValidator() {
		return Validation.buildDefaultValidatorFactory().getValidator();
	}

}
