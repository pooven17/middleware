package com.pooven.middleware.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.pooven.middleware.model.MiddlewareReq;

import reactor.core.publisher.Mono;

@Service
public class MiddlewareClient {

	@Autowired
	private WebClient webClient;

	/**
	 * Post the middleware request object to middleware API
	 * 
	 * @param middlewareReqVO
	 * @return
	 */
	public Mono<String> saveMiddleware2(MiddlewareReq middlewareReqVO) {
		return webClient.post().uri("http://localhost:9091/saveuser")
				.header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON.toString())
				.body(Mono.just(middlewareReqVO), MiddlewareReq.class).retrieve().bodyToMono(String.class);

	}

	public Mono<String> saveMiddleware(MiddlewareReq middlewareReqVO) {

		return webClient.post().uri("http://localhost:9091/saveuser")
				.header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON.toString())
				.body(Mono.just(middlewareReqVO), MiddlewareReq.class)
				.exchangeToMono(response -> response.bodyToMono(String.class));
	}

}
