package com.pooven.middleware.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Service;

import com.pooven.middleware.model.EventData;
import com.pooven.middleware.model.MiddlewareReq;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class MiddlewareService {

	@Autowired
	MiddlewareClient middlewareClient;

	/**
	 * Will be triggered for each event
	 * 
	 * @param message
	 * 
	 * @param msg
	 */
	public Flux<Message<String>> trigger(Message<EventData> message) {
		EventData data = message.getPayload();
		if (validate(data)) {
			MiddlewareReq middlewareReq = buildMiddlewareReq(data);
			middlewareClient.saveMiddleware(middlewareReq);
			return Flux.just("Data pushed successfully to Middleware").flatMap(this::getQueueResp);
		}
		return Flux.just("Data not pushed to Middleware").flatMap(this::getQueueResp);
	}

	private Mono<Message<String>> getQueueResp(String msg) {
		return Mono.just(MessageBuilder.withPayload(msg).build());
	}

	/**
	 * Build the Middleware Request Object for each event object
	 * 
	 * @param event
	 * @return MiddlewareReq
	 */
	private MiddlewareReq buildMiddlewareReq(EventData data) {
		MiddlewareReq.Address address = null;
		if (data.getAddress() != null) {
			address = new MiddlewareReq.Address(data.getAddress().getAddressLine1(),
					data.getAddress().getAddressLine2());
		}
		return new MiddlewareReq(data.getId(), data.getName(), address);
	}

	/**
	 * Perform validation/business logic
	 * 
	 * @param middlewareReq
	 */
	private boolean validate(EventData event) {
		return true;
	}

}
