package com.pooven.middleware.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pooven.middleware.model.EventVO;
import com.pooven.middleware.model.MiddlewareReqVO;

@Service
public class MiddlewareService {

	@Autowired
	MiddlewareClient middlewareClient;

	/**
	 * Will be triggered for each event
	 * 
	 * @param eventVO
	 */
	public void trigger(EventVO eventVO) {
		MiddlewareReqVO middlewareReqVO = buildMiddlewareReq(eventVO);
		middlewareClient.saveMiddleware(middlewareReqVO);
	}

	/**
	 * Build the Middleware Request Object for each event object
	 * 
	 * @param eventVO
	 * @return MiddlewareReqVO
	 */
	private MiddlewareReqVO buildMiddlewareReq(EventVO eventVO) {
		return new MiddlewareReqVO();
	}

	/**
	 * Perform validation/business logic
	 * 
	 * @param middlewareReqVO
	 */
	private void validate(MiddlewareReqVO middlewareReqVO) {

	}

}
